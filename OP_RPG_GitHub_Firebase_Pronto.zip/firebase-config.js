/**
 * ╔═════════════════════════════════════════════════════════════════╗
 * ║ OP RPG • CONFIGURAÇÃO DO FIREBASE — EDITE SOMENTE ESTE ARQUIVO   ║
 * ╚═════════════════════════════════════════════════════════════════╝
 *
 * Firebase Console → Configurações do projeto → Seus aplicativos → Web → SDK.
 * Cole abaixo o objeto firebaseConfig do seu aplicativo Web.
 *
 * IMPORTANTE: Estes dados são públicos por natureza. NUNCA coloque aqui uma
 * senha, chave privada de conta de serviço ou credenciais administrativas.
 * A segurança do banco fica nas regras de firestore.rules.
 */
window.OP_RPG_FIREBASE_CONFIG = {
  apiKey: 'COLE_AQUI_SUA_API_KEY',
  authDomain: 'SEU-PROJETO.firebaseapp.com',
  projectId: 'SEU-PROJETO',
  storageBucket: 'SEU-PROJETO.firebasestorage.app',
  messagingSenderId: 'SEU_MESSAGING_SENDER_ID',
  appId: 'SEU_APP_ID'
};
